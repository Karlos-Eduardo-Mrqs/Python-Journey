dobro = lambda num: num*2

print(dobro(4))
print(dobro(6))