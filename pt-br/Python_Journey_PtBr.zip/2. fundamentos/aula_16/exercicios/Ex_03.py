nomes = ["Ana", "Carlos", "Amanda", "Beatriz", "Arthur", "João"]

nomes_com_A = list(filter(lambda nome: nome.startswith("A"), nomes))

print(nomes_com_A)