# Leia um número e mostre seu quadrado, seu cubo e sua raiz quadrada (use para exponenciação).

num = float(input("Digite um numero:"))
print(f"O quadrado de {num} = {num ** 2}")
print(f"o cubo de {num} = {num ** 3}")
print(f"a raiz quadrada de {num} = {num ** 0.5:.2f}")