# Peça a idade do usuário e informe se ele pode tirar carteira de motorista (idade >= 18).

idade = int(input("Digite a idade do usuario:"))
print("Obs. : True = Verdadeiro e False = Falso")
print(f"O usuario pode dirigir ?: {idade >= 18}")