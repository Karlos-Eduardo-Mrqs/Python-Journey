# Utilize range() para imprimir uma contagem regressiva de 10 até 1.

for i in range(10,0,-1):
    print(i)