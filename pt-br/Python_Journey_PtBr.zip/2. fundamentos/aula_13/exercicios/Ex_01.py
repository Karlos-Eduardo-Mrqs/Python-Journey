def apresentacao(nome,curso):
    return f"Olá, meu nome é {nome} e sou do curso de {curso}"

aluno1 = apresentacao("Pedro Henrique","Psicologia")
print(aluno1)