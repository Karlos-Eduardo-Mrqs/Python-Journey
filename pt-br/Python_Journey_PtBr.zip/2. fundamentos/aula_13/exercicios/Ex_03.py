def separador():
    print("="*40)

print("Iniciando programa ...")
separador()
print("Processando ...")
separador()
print("Fim do programa ...")
