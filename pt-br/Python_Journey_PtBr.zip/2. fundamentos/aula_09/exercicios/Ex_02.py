# - **Contador com `while`:**
# Faça um programa que conte de 0 até 20, pulando de 2 em 2, utilizando `while`.

contador = 0
while contador != 20:
    contador += 2
    print(contador , '..')
    