# Compreensão de listas 
# Crie uma nova lista com os quadrados dos números de 1 a 10 usando list comprehension.

numeros = [i ** 2 for i in range(1,11)]
print(numeros)