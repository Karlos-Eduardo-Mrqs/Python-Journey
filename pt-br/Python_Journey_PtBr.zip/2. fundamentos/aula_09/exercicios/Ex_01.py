# - **Contar de 1 a 10 usando `for`:** 
# Crie um programa que utilize um loop `for` para imprimir os números de 1 a 10.

for i in range(1,11):
    print(i,"..")