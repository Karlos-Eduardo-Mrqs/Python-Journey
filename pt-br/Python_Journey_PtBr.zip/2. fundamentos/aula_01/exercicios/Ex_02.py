# Operadores Relacionais 02: Desenvolva um sistema que compare a idade de duas pessoas e diga quem é mais velho.

primeira_idade = int(input("Digite a idade da primeira pessoa:"))
segunda_idade = int(input("Digite a idade da segunda pessoa:"))

print("Obs.: True = Verdadeiro e False = Falso ")

print("A primeira idade é maior que a segunda ?:", primeira_idade > segunda_idade)
print("A segunda idade é maior que a primeira ?:", segunda_idade > primeira_idade)
print("As duas idades são iguais ?:", primeira_idade == segunda_idade)