# Operadores Aritméticos 01: Crie um programa que faça as quatro operações matemáticas com números fornecidos pelo usuário

num_1 = int(input("Digite o primeiro numero inteiro:"))
num_2 = int(input("Digite o segundo numero inteiro:"))

print("Operações possíveis para os números ! ")
print(num_1," + ", num_2 ," = ", num_1 + num_2)
print(num_1," - ", num_2 ," = ", num_1 - num_2)
print(num_1," * ", num_2 ," = ", num_1 * num_2)
print(num_1," / ", num_2 ," = ", num_1 / num_2)
print(num_1," // ", num_2 ," = ", num_1 // num_2)
print(num_1," % ", num_2 ," = ", num_1 % num_2)
print(num_1," ** ", num_2 ," = ", num_1 ** num_2)
