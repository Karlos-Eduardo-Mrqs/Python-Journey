# Crie um programa que peça a senha do usuário. 2. Se a senha for "python123", exiba "Acesso permitido". 3. Caso contrário, exiba "Acesso negado".

senha = input("Digite a sua senha:")
if senha == "python123":
    print("Acesso permitido")
else:
    print("Acesso negado")