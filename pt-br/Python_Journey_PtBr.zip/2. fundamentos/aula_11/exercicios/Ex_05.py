# Marcador de pass Crie um loop que percorra números de 1 a 5 e use pass quando o número for 3.

for i in range(1, 6):
    print( i if i != 3 else "..")