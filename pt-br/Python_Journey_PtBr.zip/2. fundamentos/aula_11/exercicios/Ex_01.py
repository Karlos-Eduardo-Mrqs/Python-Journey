# Contador com while Imprima os números de 1 a 20 usando while.

contador = 0
while True:
    if contador == 20:
        break
    contador += 1
    print(contador)