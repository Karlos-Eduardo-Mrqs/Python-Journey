def calcular_media(nota1, nota2):
    media = (nota1 + nota2) / 2
    print(f"A média das notas é: {media:.1f}")

# Testando a função
calcular_media(8, 7)
calcular_media(10, 9.5)
