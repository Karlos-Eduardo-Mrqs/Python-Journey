def revelar_dados(nome,cidade,idade):
    print(f"Nome: {nome} | Idade : {idade} | Cidade : {cidade}")

revelar_dados("Ana", 22, "São Paulo")
revelar_dados("Eduardo", 20, "Porto Alegre")