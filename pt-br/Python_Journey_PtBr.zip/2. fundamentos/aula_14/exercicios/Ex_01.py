def dobro(numero):
    print(f"O dobro de {numero} é {numero * 2}")

dobro(5)
dobro(7)