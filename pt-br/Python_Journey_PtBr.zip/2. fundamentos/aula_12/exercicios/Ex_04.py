def num_primo(num):
    return f"O numero {num} não é impar" if num % 2 == 0 else f"O numero {num} é impar"

print(num_primo(8))
