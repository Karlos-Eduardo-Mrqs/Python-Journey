def media(num1,num2):
    return ((num1 + num2) / 2)

media_usuario = media(8,9)
print(media_usuario)