def cont_caracteres(palavra):
    return f"temos {len(palavra)} caracteres na palavra {palavra}."

print(cont_caracteres("pimenta"))