def soma(num1, num2):
    return num1 + num2

somando = soma(5,8)
print(somando)