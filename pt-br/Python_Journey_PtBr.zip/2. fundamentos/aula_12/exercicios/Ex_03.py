def fatorial(num):
    fat = 1
    for i in range(1, num + 1):
        fat *= i
    
    return fat 
    
print(fatorial(10))