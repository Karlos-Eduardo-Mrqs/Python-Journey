lista_compras = ["arroz", "feijão", "açúcar"]
lista_compras = tuple(lista_compras)
print(lista_compras)