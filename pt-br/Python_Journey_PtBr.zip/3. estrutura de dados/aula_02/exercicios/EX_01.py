tupla_numeros = (1,2,3,2,4,2,5)
cont_2 = tupla_numeros.count(2)

print(f"A tupla tem {len(tupla_numeros)} numeros.")
print(f"A tupla tem o numero 2 aparecendo {cont_2} vezes.")
