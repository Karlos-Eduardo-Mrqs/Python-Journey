coordenadas = (15,30)
eixo_x,eixo_y = coordenadas
print(f"Eixo X:{eixo_x} e Eixo Y:{eixo_y}")