lista_num = [num for num in range(0,11)]
print(f"Primeiro número é:{lista_num[0]}")
indice_num5 = lista_num.index(5)
lista_num[indice_num5] = 50
print(lista_num)