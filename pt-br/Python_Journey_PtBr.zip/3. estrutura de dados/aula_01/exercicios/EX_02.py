lista_itens = ["arroz","feijao","macarrao"]
lista_itens.append("açucar")
lista_itens.insert(1,"sal")
lista_itens.remove("feijao")
print(lista_itens)