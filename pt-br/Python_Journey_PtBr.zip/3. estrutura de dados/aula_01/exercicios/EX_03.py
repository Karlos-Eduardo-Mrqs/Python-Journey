lista_notas = [7.5,8.0,6.0,9.0,10.0]
media = sum(lista_notas) / len(lista_notas)
maior_nota = max(lista_notas)
menor_nota = min(lista_notas)

print(f"Média: {media:.2f}")
print(f"Maior nota: {maior_nota}")
print(f"Menor nota: {menor_nota}")