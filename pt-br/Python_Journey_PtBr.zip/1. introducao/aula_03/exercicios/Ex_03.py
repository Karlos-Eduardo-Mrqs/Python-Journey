# Exercício 3: Desenvolva um dicionário que possuam nome, idade, situação(estudando: true), e entre outros

aluno = {
    "nome":"Leonardo_Queiroz",
    "idade": 24,
    "estudando": True,
    "dirige":False
}

print(aluno)