# Exercício 2: Fazer um cadastro simples com nome, idade e cidade;

nome = input("Digite o seu nome usuário:")
idade = int(input("Digite a sua idade usuário:"))
cidade = input("Digite a sigla ou nome da sua cidade:")

print("Cadastro sucedido ! ")
print("Nome:",nome," Idade:",idade," Cidade:",cidade)