# Exercício 01 : Criar um programa que calcula a média de duas notas

nota_1 = float(input("Digite a primeira nota do aluno:"))
nota_2 = float(input("Digite a segunda nota do aluno:"))

media = (nota_1 + nota_2)/2

print("Media = ", media)