# Exercício 01 : Criar um programa que calcula a média de duas notas

nota_1, nota_2 = 7.5 , 8.0 

media = (nota_1 + nota_2) / 2 
print("Media = ",media)